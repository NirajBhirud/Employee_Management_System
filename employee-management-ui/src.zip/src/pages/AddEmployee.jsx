import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import EmployeeForm from "../components/employee/EmployeeForm";

import { createEmployee } from "../services/employeeService";

export default function AddEmployee() {

    const navigate = useNavigate();

    async function handleAdd(employee) {

        try {

            await createEmployee(employee);

            toast.success("Employee Added Successfully");

            navigate("/employees");

        } catch (error) {
              console.error("Error:", error);

              if (error.response) {
                  console.log("Status:", error.response.status);
                  console.log("Data:", error.response.data);
              }

              alert("Something went wrong.");
          }

    }

    return (

        <div>

            <h1 className="text-4xl font-bold mb-8">

                Add Employee

            </h1>

            <EmployeeForm

                onSubmit={handleAdd}

                buttonText="Add Employee"

            />

        </div>

    );

}