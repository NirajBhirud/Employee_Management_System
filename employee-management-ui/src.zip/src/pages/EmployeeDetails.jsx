import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Loader from "../components/common/Loader";
import { getEmployee } from "../services/employeeService";

export default function EmployeeDetails() {

    const { id } = useParams();
    const navigate = useNavigate();

    const [employee, setEmployee] = useState(null);

    useEffect(() => {
        loadEmployee();
    }, []);

    async function loadEmployee() {
        try {
            const response = await getEmployee(id);
            setEmployee(response.data);
        } catch (error) {
            console.error(error);
        }
    }

    if (!employee) {
        return <Loader />;
    }

    return (
        <div className="max-w-3xl mx-auto">

            <div className="bg-white rounded-xl shadow-lg p-8">

                <div className="flex items-center gap-6 mb-8">

                    <div className="w-24 h-24 rounded-full bg-blue-600 text-white flex items-center justify-center text-4xl font-bold">
                        {employee.firstname.charAt(0)}
                    </div>

                    <div>
                        <h1 className="text-3xl font-bold">
                            {employee.firstname} {employee.lastname}
                        </h1>

                        <p className="text-gray-500">
                            Employee ID : {employee.id}
                        </p>
                    </div>

                </div>

                <div className="grid grid-cols-2 gap-6">

                    <div>
                        <h3 className="font-semibold">First Name</h3>
                        <p>{employee.firstname}</p>
                    </div>

                    <div>
                        <h3 className="font-semibold">Last Name</h3>
                        <p>{employee.lastname}</p>
                    </div>

                    <div>
                        <h3 className="font-semibold">Email</h3>
                        <p>{employee.email}</p>
                    </div>

                </div>

                <div className="mt-10 flex gap-4">

                    <button
                        onClick={() => navigate(`/edit/${employee.id}`)}
                        className="bg-blue-600 text-white px-5 py-3 rounded-lg hover:bg-blue-700"
                    >
                        Edit Employee
                    </button>

                    <button
                        onClick={() => navigate("/employees")}
                        className="border px-5 py-3 rounded-lg hover:bg-gray-100"
                    >
                        Back
                    </button>

                </div>

            </div>

        </div>
    );
}