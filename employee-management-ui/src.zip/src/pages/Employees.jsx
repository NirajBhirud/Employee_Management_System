import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import EmployeeTable from "../components/employee/EmployeeTable";
import SearchBar from "../components/employee/SearchBar";
import Loader from "../components/common/Loader";

import { getEmployees } from "../services/employeeService";

export default function Employees() {

    const [employees, setEmployees] = useState([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState("");

    useEffect(() => {
        loadEmployees();
    }, []);

    async function loadEmployees() {

        try {

            const response = await getEmployees();

            setEmployees(response.data);

        } catch (error) {

            console.error(error);

        } finally {

            setLoading(false);

        }

    }

    function handleDelete(id) {

        console.log("Delete Employee:", id);

    }

    const filteredEmployees = employees.filter(employee =>

        employee.firstname.toLowerCase().includes(search.toLowerCase()) ||

        employee.lastname.toLowerCase().includes(search.toLowerCase()) ||

        employee.email.toLowerCase().includes(search.toLowerCase())

    );

    return (

        <div>

            <div className="flex justify-between items-center mb-6">

                <h1 className="text-4xl font-bold">

                    Employees

                </h1>

                <div className="flex gap-3">

                    <SearchBar
                        value={search}
                        onChange={setSearch}
                    />

                    <Link
                        to="/add"
                        className="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700"
                    >
                        Add Employee
                    </Link>

                </div>

            </div>

            {

                loading ?

                    <Loader />

                    :

                    <EmployeeTable
                        employees={filteredEmployees}
                        onDelete={handleDelete}
                    />

            }

        </div>

    );

}